package br.com.webmaven.paciente.bean;

import java.io.IOException;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import br.com.webmaven.generic.bean.GenericBean;
import br.com.webmaven.paciente.entity.Paciente;
import br.com.webmaven.paciente.service.PacienteServiceBean;
import br.com.webmaven.util.atributos.StaticAttributes;

@ManagedBean (name = "pacienteBean")
@RequestScoped
public class PacienteBean extends GenericBean {
    
	private Paciente paciente;
	
	private List<Paciente> listPacientes;
	
	private PacienteServiceBean pacienteServiceBean;
	
	@PostConstruct
	public void init() {
		listarPacientes();
	}

	/**
	 * Cadastramento de paciente
	 * @throws IOException 
	 */
	public String cadastrarPaciente() throws IOException {
		this.getPacienteServiceBean().salvarPaciente(paciente);
		listarPacientes();
		super.printMessageSucess("Paciente cadastrado com sucesso!");
		return redirecionarPagConsPaciente();
	}
	
	/**
	 * Editar paciente selecionado
	 * @param paciente
	 */
	public String editarPaciente(Paciente paciente) {
		this.getPacienteServiceBean().editar(paciente);
		return StaticAttributes.PG_CONS_PACIENTE;
	}
	
	/**
	 * Excluir paciente selecionado
	 * @param paciente
	 */
	public void excluirPaciente(Paciente paciente) {
		this.getPacienteServiceBean().excluirPaciente(paciente);
		listarPacientes();
		super.printMessageSucess("Paciente excluido com sucesso!");
	}
	
	/**
	 * Retorna lista de pacientes
	 * @return
	 */
	public void listarPacientes() {
		this.listPacientes = this.getPacienteServiceBean().listarPacientes(); 
	}
	
	public String carregarPaciente(Paciente paciente) {
		this.paciente = paciente;
		return StaticAttributes.PG_CAD_PACIENTE;
	}
	
	public String retornarMenu() {
		 return StaticAttributes.PG_MENU;
	}
	
	public String redirecionarPagConsPaciente() {
		return StaticAttributes.PG_CONS_PACIENTE;
	}
	
	public String redirecionarPagCadPaciente() {
		return StaticAttributes.PG_CAD_PACIENTE;
	}

	public Paciente getPaciente() {
		if (this.paciente == null) {
			this.paciente = new Paciente();
		}
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public List<Paciente> getListPacientes() {
		return listPacientes;
	}

	public void setListPacientes(List<Paciente> listPacientes) {
		this.listPacientes = listPacientes;
	}

	public PacienteServiceBean getPacienteServiceBean() {
		if (this.pacienteServiceBean == null) {
			this.pacienteServiceBean = new PacienteServiceBean();
		}
		return pacienteServiceBean;
	}

	public void setPacienteServiceBean(PacienteServiceBean pacienteServiceBean) {
		this.pacienteServiceBean = pacienteServiceBean;
	}

}
