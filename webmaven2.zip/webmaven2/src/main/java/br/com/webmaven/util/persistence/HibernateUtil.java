package br.com.webmaven.util.persistence;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	private static final SessionFactory sessionFactory = criarSessao();

	@SuppressWarnings("deprecation")
	private static SessionFactory criarSessao() {
		try {
			return new Configuration().configure().buildSessionFactory();
		} catch (Throwable e) {
			System.err.println("ERRO: SessionFactory falhou na inicializa��o - " + e);
            throw new ExceptionInInitializerError(e);
		}
	}

	public static SessionFactory getSessionfactory() {
		return sessionFactory;
	}
	
	public static void desconectar() {
		getSessionfactory().close();
	}
}
