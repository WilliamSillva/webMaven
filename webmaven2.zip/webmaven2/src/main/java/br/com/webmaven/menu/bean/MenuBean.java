package br.com.webmaven.menu.bean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import br.com.webmaven.generic.bean.GenericBean;
import br.com.webmaven.util.atributos.StaticAttributes;

@ManagedBean(name = "menuBean")
@RequestScoped
public class MenuBean extends GenericBean {
	
	public String redirecionarPaginaConsPaciente() {
		return StaticAttributes.PG_CONS_PACIENTE;
	}

}
