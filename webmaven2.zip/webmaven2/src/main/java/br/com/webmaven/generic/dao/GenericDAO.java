package br.com.webmaven.generic.dao;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;

import br.com.webmaven.util.persistence.HibernateUtil;

public class GenericDAO<PK, T> {

	private Session session;
	
	public Session createSession() {
		this.session = HibernateUtil.getSessionfactory().openSession();
		return this.session;
	}
	
	public void closeSession() {
		this.session.close();
	}
	
//	public T getById(PK pk) {
//		return (T) entityManager.find(getTypeClass(), pk);
//	}
	
	public void save(T entity) {
		this.createSession().save(entity);
		this.session.beginTransaction().commit();
		this.session.flush();
	}
	
	public void update(T entity) {
		this.createSession().update(entity);
		this.session.beginTransaction().commit();
		this.session.flush();
	}
	
	public void delete(T entity) {
		this.createSession().delete(entity);
		this.session.beginTransaction().commit();
		this.session.flush();
	}
	
	@SuppressWarnings("unchecked")
	public List<T> findAll() {
		Criteria criteria = this.createSession().createCriteria(getTypeClass().getName());
		return criteria.list();
	}
	
	private Class<?> getTypeClass() {
		Class<?> clazz = (Class<?>) ((ParameterizedType) 
				this.getClass().getGenericSuperclass()).getActualTypeArguments()[1];
		return clazz;
	}
	
}
