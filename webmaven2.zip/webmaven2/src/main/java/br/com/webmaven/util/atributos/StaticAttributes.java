package br.com.webmaven.util.atributos;

public class StaticAttributes {

	public static final String PG_LOGIN = "login";
	
	public static final String PG_MENU = "index";
	
	public static final String PG_CAD_PACIENTE = "cadPaciente";
	
	public static final String PG_CONS_PACIENTE = "consPaciente";
	
}
