package br.com.webmaven.paciente.dao;

import java.util.List;

import br.com.webmaven.generic.dao.GenericDAO;
import br.com.webmaven.paciente.entity.Paciente;

public class PacienteDao extends GenericDAO<Long, Paciente> {

	public List<Paciente> findAll() {
		return super.findAll();
	}
	
}
