package br.com.webmaven.paciente.service;

import java.util.List;

import br.com.webmaven.paciente.dao.PacienteDao;
import br.com.webmaven.paciente.entity.Paciente;

public class PacienteServiceBean {

	private PacienteDao dao = new PacienteDao();
	
	public void salvarPaciente(Paciente paciente) {
		dao.save(paciente);
	}
	
	public List<Paciente> listarPacientes() {
		return dao.findAll();
	}
	
	public void excluirPaciente(Paciente paciente) {
		dao.delete(paciente);
	}

	public void editar(Paciente paciente) {
		dao.update(paciente);
	}
}
