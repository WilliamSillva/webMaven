package br.com.webmaven.login.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import br.com.webmaven.generic.dao.GenericDAO;
import br.com.webmaven.usuario.entity.Usuario;

public class LoginDao extends GenericDAO<Long, Usuario>{

	public Usuario buscarUsuario(Usuario usuario) {
		Session session = super.createSession();
		Criteria criteria = session.createCriteria(Usuario.class);
		criteria.add(Restrictions.eq("email", usuario.getEmail()));
		criteria.add(Restrictions.eq("senha", usuario.getSenha()));
		
		Usuario user = (Usuario) criteria.uniqueResult();
		session.close();
		return user;
	}
	
//	public void adicionarUsuario(Usuario usuario) {
//		Session session = HibernateUtil.getSessionfactory().openSession();
//		session.beginTransaction();
//		
//		session.save(usuario);
//		session.getTransaction().commit();
//	}
	
}
