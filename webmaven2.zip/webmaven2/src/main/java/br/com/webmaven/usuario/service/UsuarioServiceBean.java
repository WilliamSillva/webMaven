package br.com.webmaven.usuario.service;

import br.com.webmaven.login.dao.LoginDao;
import br.com.webmaven.usuario.entity.Usuario;
import br.com.webmaven.util.md5.ConvertKey;

public class UsuarioServiceBean {

	private LoginDao loginDao = new LoginDao();
	
	public Usuario isUsuarioReadyToLogin(String email, String senha) {
		try {
			Usuario user = new Usuario();
			email = email.toLowerCase().trim();
			user.setEmail(email);
			user.setSenha(ConvertKey.convertStringToMd5(senha));
			Usuario usuarioLogado = loginDao.buscarUsuario(user);

			if (usuarioLogado != null) {
				return usuarioLogado;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
