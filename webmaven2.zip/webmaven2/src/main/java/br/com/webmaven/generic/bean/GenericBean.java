package br.com.webmaven.generic.bean;

import java.io.IOException;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

public class GenericBean {

	public static HttpSession getSession(){
		return ((HttpServletRequest)FacesContext.getCurrentInstance().getExternalContext().getRequest()).getSession();
	}

	public void redirecionar(String pag) {
		try {
			FacesContext
				.getCurrentInstance()
				.getExternalContext()
				.redirect(pag);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void printMessageError(String msg) {
        FacesMessage fmsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, "Aten��o", msg);
        FacesContext.getCurrentInstance().addMessage(null, fmsg);
    }

	public void printMessageSucess(String msg) {
        FacesMessage fmsg = new FacesMessage(FacesMessage.SEVERITY_INFO, "WebMaven", msg);
        FacesContext.getCurrentInstance().addMessage(null, fmsg);
    }

}
