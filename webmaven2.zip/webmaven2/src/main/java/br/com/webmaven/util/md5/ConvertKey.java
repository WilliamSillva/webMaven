package br.com.webmaven.util.md5;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class ConvertKey {

	public static String convertStringToMd5(String senha) {
		MessageDigest mDigest;
		
		try {
			mDigest = MessageDigest.getInstance("MD5");
			byte []valorMd5 = mDigest.digest(senha.getBytes("UTF-8"));
			
			StringBuffer sb = new StringBuffer();
			for (byte b : valorMd5) {
				sb.append(Integer.toHexString((b & 0xFF) | 0x100).substring(1,3));
			}
			
			return sb.toString();
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		}
	}
}
