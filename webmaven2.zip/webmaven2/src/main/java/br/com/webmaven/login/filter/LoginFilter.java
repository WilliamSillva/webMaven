package br.com.webmaven.login.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.webmaven.usuario.entity.Usuario;


public class LoginFilter implements Filter{

	private Usuario usuario;
	
	private boolean usuarioLogado;

	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
	}
		 
	public void destroy() {
		// TODO Auto-generated method stub
	}
	 
	public void doFilter(ServletRequest request, ServletResponse response,
	        FilterChain chain) throws IOException, ServletException {
		
		if (((HttpServletRequest) request).getSession().getAttribute("log") == null) {
			this.usuarioLogado = Boolean.FALSE;
		} else {
			this.usuarioLogado = (boolean) ((HttpServletRequest) request).getSession().getAttribute("log");
		}
		
		usuario = (Usuario) ((HttpServletRequest) request).getSession().getAttribute("user");
		//LoginBean login = (LoginBean) ((HttpServletRequest) request).getSession().getAttribute("loginBean");
		 
		if (this.usuario == null || !this.usuarioLogado) {
			String contextPath = ((HttpServletRequest) request).getContextPath();
			((HttpServletResponse) response).sendRedirect(contextPath + "/login/login.jsf");
		} else {
			//Continua o fluxo
		    chain.doFilter(request, response);
		}
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public boolean isUsuarioLogado() {
		return usuarioLogado;
	}

	public void setUsuarioLogado(boolean usuarioLogado) {
		this.usuarioLogado = usuarioLogado;
	}
	
}
