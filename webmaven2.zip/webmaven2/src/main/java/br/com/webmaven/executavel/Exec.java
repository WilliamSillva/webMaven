package br.com.webmaven.executavel;

import br.com.webmaven.util.md5.ConvertKey;

public class Exec {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		ConvertKey convert = new ConvertKey();
		System.out.println(convert.convertStringToMd5("123"));

	}

}
