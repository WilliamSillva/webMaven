package br.com.webmaven.login.bean;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

import br.com.webmaven.generic.bean.GenericBean;
import br.com.webmaven.usuario.entity.Usuario;
import br.com.webmaven.usuario.service.UsuarioServiceBean;
import br.com.webmaven.util.atributos.StaticAttributes;

@ManagedBean (name = "loginBean")
@SessionScoped
public class LoginBean extends GenericBean {
	
	private Usuario usuarioLogado;
	
	private boolean loggedIn;
	
	private String senha;
	
	private String email = "will@msn.com";
    
    private UsuarioServiceBean usuarioServiceBean;
    

	/**
	 * M�todo que realiza o login
	 * @return
	 */
	public String logarUsuario() {
		//Verifica se o e-mail e senha existem         
        Usuario usuarioFound = this.getUsuarioServiceBean().isUsuarioReadyToLogin(email, senha);
		
        //Caso usu�rio ou senha estiver incorreto   
        if (usuarioFound == null){
          FacesContext.getCurrentInstance().validationFailed();
          printMessageError("Email e/ou Senha errado. Tente novamente!");
          return StaticAttributes.PG_LOGIN;     
        } else {
          this.setLoggedIn(Boolean.TRUE);
          this.usuarioLogado = usuarioFound;
          
          getSession().setAttribute("log", this.isLoggedIn());
          getSession().setAttribute("user", this.usuarioLogado);
          
          printMessageSucess("Bem vindo ao sistema " + this.usuarioLogado.getNome());
          return StaticAttributes.PG_MENU;
        }

	}
	
	/**
	 * Logout
	 * @return
	 */
	public String logout() {
		this.setUsuarioLogado(null);
		this.loggedIn = Boolean.FALSE;
		
		getSession().setAttribute("log", this.isLoggedIn());
        getSession().setAttribute("user", this.usuarioLogado);
         
		printMessageSucess("Logout realizado com sucesso!");
		return "/login/login.jsf";
	}

	public Usuario getUsuarioLogado() {
		if (usuarioLogado == null) {
			usuarioLogado = new Usuario();
		}
		return usuarioLogado;
	}

	public void setUsuarioLogado(Usuario usuarioLogado) {
		this.usuarioLogado = usuarioLogado;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isLoggedIn() {
		return loggedIn;
	}

	public void setLoggedIn(boolean loggedIn) {
		this.loggedIn = loggedIn;
	}

	public UsuarioServiceBean getUsuarioServiceBean() {
		if (usuarioServiceBean == null) {
			usuarioServiceBean = new UsuarioServiceBean();
		}
		return usuarioServiceBean;
	}

	public void setUsuarioServiceBean(UsuarioServiceBean usuarioServiceBean) {
		this.usuarioServiceBean = usuarioServiceBean;
	}
	
}
